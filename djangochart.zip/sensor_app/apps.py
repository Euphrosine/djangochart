from django.apps import AppConfig


class SensorAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'sensor_app'

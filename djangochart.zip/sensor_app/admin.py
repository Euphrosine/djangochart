from django.contrib import admin

from . models import SensorData



admin.site.register(SensorData)
